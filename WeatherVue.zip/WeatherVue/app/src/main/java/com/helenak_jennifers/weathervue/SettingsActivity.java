package com.helenak_jennifers.weathervue;
import static com.helenak_jennifers.weathervue.R.id.rv_english_language;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
public class SettingsActivity extends BaseActivity implements View.OnClickListener {
    private TextView textViewEnglish;
    private TextView textViewArabic;
    private TextView textViewCelsius;
    private TextView textViewFahrenheit;
    private ImageView imageViewEnglish;
    private ImageView imageViewArabic;
    private ImageView imageViewCelsius;
    private ImageView imageViewFahrenheit;
    private TextView textViewUnitTitle;
    private List<TextView> textViewList;
    private TextView textViewLangTitle;
    private TextView textViewSetTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
         textViewList = new ArrayList<>();
        String languageName = SharedPreference.getString(this, "language", "en");
        String unitName = SharedPreference.getString(this, "unit", "Metric");

        RelativeLayout LayoutEnglish = findViewById(rv_english_language);
        RelativeLayout LayoutArabic = findViewById(R.id.rv_arabic_language);
        RelativeLayout LayoutCelsius = findViewById(R.id.rv_celsius);
        RelativeLayout LayoutFahrenheit = findViewById(R.id.rv_fahrenheit);

        textViewSetTitle = findViewById(R.id.tv_setting_title);
        textViewLangTitle = findViewById(R.id.tv_choose_lang);
        textViewUnitTitle = findViewById(R.id.tv_choose_unit);

        textViewEnglish = findViewById(R.id.tv_en_right);
        textViewArabic = findViewById(R.id.tv_ar_right);
        textViewCelsius = findViewById(R.id.tv_celsius_right);
        textViewFahrenheit = findViewById(R.id.tv_fahrenheit_right);

        imageViewEnglish = findViewById(R.id.iv_en_right);
        imageViewArabic = findViewById(R.id.iv_ar_right);
        imageViewCelsius = findViewById(R.id.iv_celsius_right);
        imageViewFahrenheit = findViewById(R.id.iv_fahrenheit_right);

        LayoutEnglish.setOnClickListener(this);
        LayoutArabic.setOnClickListener(this);
        LayoutCelsius.setOnClickListener(this);
        LayoutFahrenheit.setOnClickListener(this);

        textViewList.add(textViewLangTitle);
        textViewList.add(textViewUnitTitle);

        textViewList.add(textViewEnglish);
        textViewList.add(textViewArabic);
        textViewList.add(textViewCelsius);
        textViewList.add(textViewFahrenheit);

        if ("en".equals(languageName)) {
            selectView(textViewEnglish, imageViewEnglish);
            unSelectView(textViewArabic, imageViewArabic);
        } else if ("ar".equals(languageName)) {
            selectView(textViewArabic, imageViewArabic);
            unSelectView(textViewEnglish, imageViewEnglish);
        }

        if ("Celsius".equals(unitName)) {
            selectView(textViewCelsius, imageViewCelsius);
            unSelectView(textViewFahrenheit, imageViewFahrenheit);
        } else if ("Fahrenheit".equals(unitName)) {
            selectView(textViewFahrenheit, imageViewFahrenheit);
            unSelectView(textViewCelsius, imageViewCelsius);
        }
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == rv_english_language) {
            SharedPreference.saveString(this, "language", "en");
            Constant.appSettingLang = "en";
            selectView(textViewEnglish, imageViewEnglish);
            unSelectView(textViewArabic, imageViewArabic);
            changeLanguage();
        } else if (id == R.id.rv_arabic_language) {
            SharedPreference.saveString(this, "language", "ar");
            Constant.appSettingLang = "ar";
            selectView(textViewArabic, imageViewArabic);
            unSelectView(textViewEnglish, imageViewEnglish);
            changeLanguage();
        } else if (id == R.id.rv_celsius) {
            Constant.unitChange = true;
            SharedPreference.saveString(this, "unit", "Celsius");
            SharedPreference.saveString(this, "WeatherUnit", "Metric");
            Constant.appSettingUnit = "Celsius";
            selectView(textViewCelsius, imageViewCelsius);
            unSelectView(textViewFahrenheit, imageViewFahrenheit);
        } else if (id == R.id.rv_fahrenheit) {
            Constant.unitChange = true;
            Constant.appSettingUnit = "Fahrenheit";
            SharedPreference.saveString(this, "unit", "Fahrenheit");
            SharedPreference.saveString(this, "WeatherUnit", "Imperial");
            selectView(textViewFahrenheit, imageViewFahrenheit);
            unSelectView(textViewCelsius, imageViewCelsius);
        }
    }
    private void selectView(TextView textView, ImageView imageView) {
        textView.setTextColor(getResources().getColor(R.color.black));
        imageView.setVisibility(View.VISIBLE);
    }
    private void unSelectView(TextView textView, ImageView imageView) {
        textView.setTextColor(getResources().getColor(R.color.black));
        imageView.setVisibility(View.GONE);
    }
    private void changeLanguage() {
        Constant.changeLang = true;
        textViewLangTitle.setText(R.string.choose_language);
        textViewUnitTitle.setText(R.string.choose_unit);
        textViewEnglish.setText(R.string.english);
        textViewArabic.setText(R.string.arabic);
        textViewCelsius.setText(R.string.celsius);
        textViewFahrenheit.setText(R.string.fahrenheit);
        textViewSetTitle.setText(R.string.settings);
    }
}