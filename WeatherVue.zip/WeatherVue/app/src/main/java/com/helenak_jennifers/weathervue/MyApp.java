package com.helenak_jennifers.weathervue;
import android.app.Application;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.google.firebase.FirebaseApp;
public class MyApp extends Application {
    private static MyApp instance = null;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }
    public static Context getContext() {
        return instance.getApplicationContext();
    }
}
