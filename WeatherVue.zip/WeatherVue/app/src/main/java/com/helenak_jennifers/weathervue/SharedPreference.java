package com.helenak_jennifers.weathervue;
import android.content.Context;
import android.content.SharedPreferences;
public class SharedPreference {
        public static String preferenceName = "WeatherVuePref";
        public static boolean saveString(Context context,String key,String value) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(key, value);
            return editor.commit();
        }
        public static String getString(Context context,String key,String value) {
            SharedPreferences sharedPreferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return sharedPreferences.getString(key,value);
        }
}