package com.helenak_jennifers.weathervue;
import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
public class MainActivity extends BaseActivity implements OnMapReadyCallback {
    ImageView imageViewSetting;
    GoogleMap googleMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    EditText editTextSearch;
    TextView textViewToday;
    TextView textViewTomorrow;
    TextView textViewTemperatureToday;
    TextView textViewTemperaturetomorrow;
    ImageView imageViewSearch;
    private FirebaseFirestore firebaseFirestore;
    LatLng latLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewSetting = (ImageView) findViewById(R.id.ic_settings);
        editTextSearch = findViewById(R.id.searchView);
        textViewToday = findViewById(R.id.tv_day1);
        textViewTomorrow = findViewById(R.id.tv_day2);
        textViewTemperatureToday = findViewById(R.id.tv_temp1);
        textViewTemperaturetomorrow = findViewById(R.id.tv_temp2);
        imageViewSearch = findViewById(R.id.ic_search);

        FirebaseApp.initializeApp(this);
        firebaseFirestore = FirebaseFirestore.getInstance();
        fusedLocationProviderClient = getFusedLocationProviderClient(this);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) { return; }

        startService(new Intent(MainActivity.this, UserLocationService.class));
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        imageViewSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        imageViewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextSearch.getText().toString() != null)
                {
                    new WeatherByCityName(editTextSearch.getText().toString()).start();
                    saveSearchedDataToFirestore(editTextSearch.getText().toString(), geocodePlaceFromLatLong(MainActivity.this, latLng));
                }
            }
        });
        batteryBroadcastReceiver();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        this.googleMap.clear();
        this.googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        this.googleMap.getUiSettings().setMapToolbarEnabled(false);
        if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) { return; }
        this.googleMap.setMyLocationEnabled(true);

        if(this.googleMap.isIndoorEnabled())
        {
            this.googleMap.setIndoorEnabled(false);
        }
        this.googleMap.getUiSettings().setZoomControlsEnabled(true);
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                    LatLng latLng1 = new LatLng(location.getLatitude(), location.getLongitude());
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng1, 16.0f);
                    MainActivity.this.googleMap.clear();
                    MainActivity.this.googleMap.animateCamera(cameraUpdate);
                    MarkerOptions markerOptions = new MarkerOptions().position(new LatLng(latLng1.latitude, latLng1.longitude)).title("Current Location");
                    MainActivity.this.googleMap.addMarker(markerOptions);
                    latLng = new LatLng(location.getLatitude(), location.getLongitude());
                    new WeatherByLatLon(location.getLatitude(), location.getLongitude()).start();
                }
        });
    }
    class WeatherByCityName extends Thread {
        String city;
        WeatherByCityName(String city)
        {
            this.city = city;
        }

        @Override
        public void run() {
            OkHttpClient okHttpClient = new OkHttpClient();
            Request request = new Request.Builder().url("https://api.openweathermap.org/data/2.5/forecast/?q="+city+"&appid="+"21802dbbdc28930ca10b31ce06c2f681"+"&cnt=7" +
                            "&units="+Constant.weatherUnit).get().build();
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            try {
                Response response = okHttpClient.newCall(request).execute();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {}

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        try
                        {
                            String bodayData = response.body().string();
                            JSONObject jsonObject = new JSONObject(bodayData);
                            JSONObject cityObject = jsonObject.getJSONObject("city");
                            JSONObject coordinateObject = cityObject.getJSONObject("coord");
                            double latitude = coordinateObject.getDouble("lat");
                            double longitude = coordinateObject.getDouble("lon");
                            updateLocationOnMap(latitude, longitude);
                            getWeatherData(jsonObject);
                        }
                        catch (JSONException jsonException) {}
                    }
                });
            }
            catch (IOException ioException){}
        }
    }
    public class WeatherByLatLon extends Thread {
        double lat;
        double lon;
        WeatherByLatLon(double lat,double lon)
        {
            this.lat = lat;
            this.lon = lon;
        }

        @Override
        public void run() {
            OkHttpClient okHttpClient = new OkHttpClient();
            Request request = new Request.Builder().url("https://api.openweathermap.org/data/2.5/forecast/?lat=" + lat + "&lon=" + lon + "&cnt=7"+"&appid="+"21802dbbdc28930ca10b31ce06c2f681"+"&units=" + Constant.weatherUnit)
                    .get().build();
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            try {
                Response response = okHttpClient.newCall(request).execute();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {}

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        try {
                            String bodyData = response.body().string();
                            JSONObject jsonObject = new JSONObject(bodyData);
                            getWeatherData(jsonObject);
                        }
                        catch (JSONException jsonException) {}
                    }
                });
            }
            catch (IOException e) {}
        }
    }
    private void getWeatherData(JSONObject jsonObject) throws JSONException {
        JSONArray jsonArray = jsonObject.getJSONArray("list");
        JSONObject jsonObject1 = jsonArray.getJSONObject(0);
        JSONObject mainObject = jsonObject1.getJSONObject("main");
        double temperature = mainObject.getDouble("temp");
        String temp = null;
        String temp2 = null;
        if (Constant.appSettingUnit.equals("Celsius"))
        {
            temp = Math.round(temperature) + "℃";
        }
        else
        {
            temp = Math.round(temperature) + "℉";
        }
        setDataOnTextView(textViewToday, getResources().getString(R.string.today));
        setDataOnTextView(textViewTemperatureToday, temp);

        for(int i = 0; i < jsonArray.length(); i++)
        {
            JSONObject jsonObject2 = jsonArray.getJSONObject(i);
            String dt_txt = jsonObject2.getString("dt_txt");
            String[] split = dt_txt.split(" ");
            if(split[1].equals("00:00:00"))
            {
                JSONObject mainObject2 = jsonObject2.getJSONObject("main");
                double temperature2 = mainObject2.getDouble("temp");
                if (Constant.appSettingUnit.equals("Celsius"))
                {
                    temp2 = Math.round(temperature2) + "℃";
                }
                else
                {
                    temp2 = Math.round(temperature2) + "℉";
                }
                setDataOnTextView(textViewTomorrow, getResources().getString(R.string.tomorrow));
                setDataOnTextView(textViewTemperaturetomorrow, temp2);
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, getResources().getString(R.string.weather_update_msg), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void setDataOnTextView(final TextView textView, final String value){
        runOnUiThread(new Runnable() {
            @Override
            public void run() { textView.setText(value); }
        });
    }
    private void saveSearchedDataToFirestore(String searchedLocation, String userLocation) {
        CollectionReference collectionReference = firebaseFirestore.collection("SearchedLocations");
        SearchedLocation searchedLoc = new SearchedLocation(searchedLocation, userLocation);
        collectionReference.add(searchedLoc).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                Toast.makeText(MainActivity.this, getResources().getString(R.string.firetore_msg), Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {}
        });
    }
    public static String geocodePlaceFromLatLong(Context context, LatLng latLng) {
        try {
            Geocoder geocoder = new Geocoder(context,Locale.getDefault());
            List<Address> addressList = geocoder.getFromLocation(latLng.latitude,latLng.longitude, 1);
            return addressList.get(0).getAddressLine(0);
        } catch (Exception exception) {
            return "";
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1) {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                if(ActivityCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {}
            }
        }
    }
    private void batteryBroadcastReceiver()
    {
        BroadcastReceiver batteryLowReceiver = new BatteryLowReceiver();
        IntentFilter intentFilter = new IntentFilter(BatteryManager.EXTRA_BATTERY_LOW);
        intentFilter.addAction(Intent.ACTION_BATTERY_LOW);
        this.registerReceiver(batteryLowReceiver,intentFilter);
    }
    public class BatteryLowReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            stopService(new Intent(MainActivity.this, UserLocationService.class));
        }
    }
    private void updateLocationOnMap(double latitude, double longitude)
    {
        LatLng latlng = new LatLng(latitude,longitude);
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latlng, 16.0f);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                googleMap.clear();
                googleMap.animateCamera(cameraUpdate);
                MarkerOptions markerOptions = new MarkerOptions().position(new LatLng(latlng.latitude, latlng.longitude)).title("Current Location");
                googleMap.addMarker(markerOptions);
            }
        });
    }
}