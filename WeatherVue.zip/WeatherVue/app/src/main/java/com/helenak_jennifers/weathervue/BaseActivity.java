package com.helenak_jennifers.weathervue;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
    @Override
    public Resources getResources()
    {
        Resources resource = super.getResources();
        Configuration config = resource.getConfiguration();
        if(Constant.appSettingLang.equals("en"))
        {
            Locale enLocale = new Locale("en");
            config.locale= enLocale;
            Constant.sysLang ="en";}
        else{
            Locale arLocale = new Locale("ar");
            config.locale = arLocale;
            Constant.sysLang = "ar";}
        resource.updateConfiguration(config, resource.getDisplayMetrics());
        return resource;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}