package com.helenak_jennifers.weathervue;

public class Constant {
    public static String appSettingLang = SharedPreference.getString(MyApp.getContext(), "language", "en");
    public static String appSettingUnit = SharedPreference.getString(MyApp.getContext(), "unit", "Celsius");
    public static String weatherUnit = SharedPreference.getString(MyApp.getContext(), "WeatherUnit", "Metric");
    public static boolean unitChange = false;
    public static boolean changeLang = false;
    public static String sysLang ="en";
}