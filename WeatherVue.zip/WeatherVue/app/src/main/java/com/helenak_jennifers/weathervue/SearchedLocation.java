package com.helenak_jennifers.weathervue;

public class SearchedLocation {
    private String searchedLocation;
    private String userLocation;

    public SearchedLocation() {}
    public SearchedLocation(String searchedLocation, String userLocation) {
        this.searchedLocation = searchedLocation;
        this.userLocation = userLocation;
    }
    public String getSearchedLocation() {
        return searchedLocation;
    }
    public void setSearchedLocation(String searchedLocation) {
        this.searchedLocation = searchedLocation;
    }
    public String getUserLocation() {
        return userLocation;
    }
    public void setUserLocation(String userLocation) {
        this.userLocation = userLocation;
    }
}