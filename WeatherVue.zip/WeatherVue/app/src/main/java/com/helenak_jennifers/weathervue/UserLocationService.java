package com.helenak_jennifers.weathervue;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.StrictMode;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
public class UserLocationService extends Service implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {
        private Context context;
        protected GoogleApiClient apiClient;
        protected LocationSettingsRequest locationSettingsRequest;
        private FusedLocationProviderClient fusedLocationProviderClient;
        private SettingsClient settingClient;
        private LocationCallback locationCallback;
        private LocationRequest locationRequest;
        private Location currentLocation;

        @Override
        public void onCreate() {
            super.onCreate();
            context = this;
        }

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            googleApiClient();
            return START_STICKY;
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
        }

        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onLocationChanged(Location location) {
            new WeatherByLatLon(location.getLatitude(), location.getLongitude()).start();
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {}
        @Override
        public void onProviderEnabled(String provider) {}
        @Override
        public void onProviderDisabled(String provider) {}

        @Override
        public void onConnected(@Nullable Bundle bundle)
        {
            locationRequest = new LocationRequest();
            locationRequest.setInterval(10000);
            locationRequest.setFastestInterval(10000);
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
            builder.addLocationRequest(locationRequest);
            builder.setAlwaysShow(true);
            locationSettingsRequest = builder.build();
            settingClient.checkLocationSettings(locationSettingsRequest)
                    .addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
                        @Override
                        public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                            locationUpdate();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception)
                        {
                            int code =((ApiException)exception).getStatusCode();
                            switch (code)
                            {
                                case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                    try
                                    {
                                        ResolvableApiException resolvableApiException = (ResolvableApiException) exception;
                                        resolvableApiException.startResolutionForResult((AppCompatActivity) context, 210);}
                                    catch (IntentSender.SendIntentException sendIntentException) {}
                                    break;
                                case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            }
                        }
                    }).addOnCanceledListener(new OnCanceledListener() {
                        @Override
                        public void onCanceled() {}
                    });
        }

        @Override
        public void onConnectionSuspended(int i) {connectGoogleClient();}

        @Override
        public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {googleApiClient();}

        protected synchronized void googleApiClient() {
            fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context);
            settingClient = LocationServices.getSettingsClient(context);
            apiClient = new GoogleApiClient.Builder(context).addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
            connectGoogleClient();
            locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                    currentLocation = locationResult.getLastLocation();
                    onLocationChanged(currentLocation);}
            };
        }
        private void connectGoogleClient() {
            GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
            int result = googleApiAvailability.isGooglePlayServicesAvailable(context);
            if (result == ConnectionResult.SUCCESS) {
                apiClient.connect();}
        }
        @SuppressLint("MissingPermission")
        private void locationUpdate() {fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());}

    public class WeatherByLatLon extends Thread {
        double lat;
        double lon;

        WeatherByLatLon(double lat,double lon)
        {
            this.lat = lat;
            this.lon = lon;
        }

        @Override
        public void run() {
            OkHttpClient okHttpClient = new OkHttpClient();
            Request request = new Request.Builder().url("https://api.openweathermap.org/data/2.5/forecast/?lat="+lat+"&lon=" +lon+"&cnt=7"+"&appid="+"21802dbbdc28930ca10b31ce06c2f681"+"&units=" +Constant.weatherUnit)
                    .get().build();
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            try {
                Response response = okHttpClient.newCall(request).execute();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {}
                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        try {
                            String bodyData = response.body().string();
                            JSONObject jsonObject = new JSONObject(bodyData);
                            getWeatherData(jsonObject);
                        } catch (JSONException jsonException) {}
                    }
                });
            } catch (IOException ioException) {}
        }
    }
    private void getWeatherData(JSONObject jsonObject) throws JSONException {
        JSONArray jsonArray = jsonObject.getJSONArray("list");
        JSONObject jsonObject1 = jsonArray.getJSONObject(0);
        JSONObject mainObject = jsonObject1.getJSONObject("main");
        double temperature = mainObject.getDouble("temp");
        String temp = null;
        String temp2 = null;
        if (Constant.appSettingUnit.equals("Celsius"))
        {
            temp = Math.round(temperature) + "℃";
        }
        else
        {
            temp = Math.round(temperature) + "℉";
        }

        for (int i = 0; i < jsonArray.length(); i++)
        {
            JSONObject jsonObject2 = jsonArray.getJSONObject(i);
            String dt_txt = jsonObject2.getString("dt_txt");
            String[] dateArray = dt_txt.split(" ");
            if (dateArray[1].equals("00:00:00"))
            {
                JSONObject mainObject2 = jsonObject2.getJSONObject("main");
                double temperature2 = mainObject2.getDouble("temp");
                if (Constant.appSettingUnit.equals("Celsius"))
                {
                    temp2 = Math.round(temperature2) + "℃";
                }
                else
                {
                    temp2 = Math.round(temperature2) + "℉";
                }
            }
        }
        showNotification("Today: " + temp + ", " + "Tomorrow: " + temp2);
    }
    private void showNotification(String weather)
    {
        String channelid = "com.helenak_jennifers.weathervue.noti";
        int notificationid = 101;

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel notificationChannel = new NotificationChannel(channelid, "Weather Notification", NotificationManager.IMPORTANCE_HIGH);
        notificationChannel.setDescription("Weather Notification");
        notificationChannel.enableLights(true);
        notificationManager.createNotificationChannel(notificationChannel);

        Notification notification = new Notification.Builder(context,channelid)
                .setContentTitle("Weather update")
                .setContentText(weather)
                .setSmallIcon(R.drawable.logo)
                .setChannelId(channelid)
                .build();
        notificationManager.notify(notificationid, notification);
    }
}
